package com.example.zakazivanjetermina;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class zakazivanje extends AppCompatActivity {
    String username = "";
    String datum = "";
    String vrijeme = "";
    String cijena = "";
    String sport = "";

    private EditText sportEdit,datumEdit,vrijemeEdit,usernameEdit,cijenaEdit;
    String phoneNo = "+38268835943";
    private Button dugme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zakazivanje);


        Intent iin= getIntent();
        Bundle b = iin.getExtras();

        if(b!=null)
        {
            username =(String) b.get("UserName");
            datum =(String) b.get("Datum");
            vrijeme =(String) b.get("Vrijeme");
            cijena =(String) b.get("Cijena");
            sport =(String) b.get("Sport");

        }


        dugme = findViewById(R.id.dugme);

        sportEdit= findViewById(R.id.sport);
        datumEdit = findViewById(R.id.datum);
        vrijemeEdit = findViewById(R.id.vrijeme);
        cijenaEdit = findViewById(R.id.cijena);
        usernameEdit = findViewById(R.id.username);


        usernameEdit.setText(username);
        sportEdit.setText(sport);
        datumEdit.setText(datum);
        vrijemeEdit.setText(vrijeme);
        cijenaEdit.setText(cijena);


        dugme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String poruka = "Uspješno ste zakazali termin. Username: " + usernameEdit.getText().toString() + "\n Datum: " + datumEdit.getText().toString() + "\n Vrijeme " + vrijemeEdit.getText().toString() + "\n Cijena " + cijenaEdit.getText().toString();
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, poruka, null, null);
                Toast.makeText(zakazivanje.this, poruka, Toast.LENGTH_LONG).show();

            }
        });




    }
}
